---
name: Spec question
about: The specification is unclear and you need clarification
title: '[spec question] '
labels: spec-question
---

## Section
## What the spec says
## What is unclear
## What you are building
## Proposed clarification (optional)
