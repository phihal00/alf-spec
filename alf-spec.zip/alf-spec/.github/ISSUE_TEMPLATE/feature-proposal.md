---
name: Feature proposal
about: Propose a change or addition to the ALF specification
title: '[proposal] '
labels: feature-proposal
---

## Problem
## Proposed change
## Impact on conformance
## Alternatives considered
## Affected sections

*Spec changes require a prior accepted issue before a PR will be reviewed.*
