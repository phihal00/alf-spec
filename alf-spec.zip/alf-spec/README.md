# ALF Spec — Azail Layer Format

**The open specification for portable, model-neutral expert reasoning layers.**

→ Full documentation: [dotalf.com](https://dotalf.com) *(launching soon)*  
→ Reference implementation: [Azail](https://azail.ai)

---

## What is ALF?

The Azail Layer Format (ALF) is an open file format for encoding expert reasoning in a structured, portable way that any AI model can read. An `.alf` file tells a language model how a domain expert thinks — the evaluative sequences, the things non-experts don't know to ask, the procedural constraints, and the private data to connect at runtime.

ALF is not a model. It is not a prompt template. It is a structured container for cognitive expertise that any conformant platform can assemble into context before a query reaches the model. The same `.alf` file works with Claude, GPT-4, Gemini, or any other language model.

## Why open?

A format that belongs to one company is a proprietary feature. A format that belongs to the ecosystem is infrastructure. ALF is designed to outlast any single platform — the spec is the durable thing, and it lives here.

## Repository contents

| Path | What it is |
|---|---|
| `spec/alf-v1.md` | The complete normative ALF v1 specification |
| `spec/schema-v1.json` | JSON Schema for conformance validation |
| `examples/minimal-reference.alf.json` | A minimal conformant file for testing readers |
| `examples/clinical-differential-reasoning.alf.json` | Benchmark quality example — chest pain triage |
| `community-layers/` | Community-contributed layers under CC BY 4.0 |
| `llms.txt` | Machine-readable spec summary for LLM agents |

## Quick start

**Read the spec:** [`spec/alf-v1.md`](spec/alf-v1.md)

**Validate a file:**

```bash
npx ajv validate -s spec/schema-v1.json -d your-layer.alf.json
```

**Write a layer:** Start from `examples/minimal-reference.alf.json`. Replace the content, generate a new UUID v4 for `metadata.layer_id`, and validate against the schema.

## The nine sections

Every `.alf` file contains exactly nine top-level sections:

1. `metadata` — identity, type, attribution, licence
2. `trigger_conditions` — when the layer should activate
3. `required_inputs` — what context the layer needs
4. `enhancement_templates` — the core instructions that reshape model behaviour
5. `conversation_map` — multi-turn sequences
6. `blind_spots` — things the non-expert doesn't know they don't know
7. `error_correction_patterns` — common mistakes and how to catch them
8. `unknown_unknowns` — named insights an expert raises that the non-expert never thinks to ask
9. `search_tags` — semantic tags for platform matching

## Four layer types

- **Reasoning** — encodes how an expert thinks and evaluates
- **Procedure** — encodes a sequence with a defined correct order
- **Context** — carries standing facts, precedents, or constraints
- **Data** — a pointer to external runtime data (the data never enters the file)

## The open/private boundary

ALF is an open format. Anyone can read the spec, write an `.alf` file, and build a conformant reader or validator — no licence required.

What makes a live layer valuable — verified authorship, continuous refinement, platform-computed quality metrics, and runtime-fetched private data — is not in the file at all. ALF v1 defines no encryption-at-rest or per-install watermarking. The protection is structural, not cryptographic. See `spec/alf-v1.md §14`.

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md).

## Licence

The specification and JSON Schema are published under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Attribution: Azail AB, dotalf.com.

The format itself is open — no licence is required to implement a reader, writer, or validator.

---

*Maintained by [Azail AB](https://azail.ai) · Spec home: [dotalf.com](https://dotalf.com)*
